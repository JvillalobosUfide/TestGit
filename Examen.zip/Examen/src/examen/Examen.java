/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examen;

import javax.swing.JOptionPane;
/**
 *
 * @author Laboratorio
 */
public class Examen {

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        // vamos a utilizar i como un contador de veces que se agrego un vehiculo
        int i;
        i=0;
        //La variable de la cantidad de dias con la lectura para el parse.
        int cant_dias;
        String lecturaDias;
        //Variable de marcas 
        String marca;
        //Contador funciona para que en el momento en donde el cliente utilice 1 siga y si pone 0 se apague
        int contador;
        String lecturaCont;
        //Aca es la lectura para las placas que funcionen de manera correcta
        String lecturaPlaca;
        int placa;
        //Ingresar el precio del vehiculo
        int precio;
        String lecturaPrecio;
        
        
        
        
       
           
        
        
        
        //Esto es par el nombre del cliente a la hora de dar la factura y para la cedula
        String nombre;
        nombre = JOptionPane.showInputDialog("Digite el nombre del cliente");
        int cedula;
        String lectCedula;
        lectCedula = JOptionPane.showInputDialog("Digite la cedula del cliente");
        cedula = Integer.parseInt(lectCedula);
        
        //En este ciclo se solicitan los datos de las variables anteriormente mencionadas
        lecturaCont = JOptionPane.showInputDialog("Bienvenido presione: 1 para iniciar");
        contador = Integer.parseInt(lecturaCont);
        while (contador != 0){
            
            lecturaPlaca = JOptionPane.showInputDialog("Digite la placa del vehiculo");
            placa = Integer.parseInt(lecturaPlaca);
            marca = JOptionPane.showInputDialog("Digite la marca del vehiculo");
            lecturaDias = JOptionPane.showInputDialog("Digite la cantidad de dias: ");
            cant_dias = Integer.parseInt(lecturaDias);
            lecturaPrecio = JOptionPane.showInputDialog("Digite el precio: ");
            precio = Integer.parseInt(lecturaPrecio);
         
            // Total funciona como la variable que multiplica el precio por la cantidad de dias
            int total;
            total = precio * cant_dias;
            
            
            //aca se da un resumen de los datos que se ingresaron del vehiculo
            JOptionPane.showMessageDialog(null, "El numero de placa es: "+ placa + "\n" + "La marca del vehiculo es: "+ marca + "\n"
            + "Cantidad de dias: " + cant_dias + "\n" + "EL precio es: "+ precio + "\n"
            + "El total es: " + total);
           
            
           
           
            
            
            
            
            
            
            
            
            
            
            
            //el metodo de salida del ciclo
            lecturaCont = JOptionPane.showInputDialog("Digite 0 para salir \nDigite 1 para un nuevo vehiculo.");
            contador = Integer.parseInt(lecturaCont);
            // aca se suma la cantidad de veces que se hace el ciclo
            i++;

            
        
        }
        
  
        
     
        
    // aca es la factura que se muestra al final
        JOptionPane.showMessageDialog(null, "////////////////////////////////////////////Facturas/////////////////////////////////////////\n"
        + "Nombre del cliente: "+ nombre +"\n"+ "Cedula del cliente: "+ cedula + "\n"+ "Cantidad de vehiculos: "+ i);
        
    }
    
}