/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen;

/**
 *
 * @author Laboratorio
 */// aca estan las clases que tuve que haber usado en el main pero que no sabia como mb☻
public class Vehiculos {
    private String marca;
    private int placa;
    private int precio;
    private int cantidad_dias;
    private boolean seguro_GPS;
    private boolean seguro_completo;

    //aca estan los getter and setters
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getPlaca() {
        return placa;
    }

    public void setPlaca(int placa) {
        this.placa = placa;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getCantidad_dias() {
        return cantidad_dias;
    }

    public void setCantidad_dias(int cantidad_dias) {
        this.cantidad_dias = cantidad_dias;
    }

    public boolean isSeguro_GPS() {
        return seguro_GPS;
    }

    public void setSeguro_GPS(boolean seguro_GPS) {
        this.seguro_GPS = seguro_GPS;
    }

    public boolean isSeguro_completo() {
        return seguro_completo;
    }

    public void setSeguro_completo(boolean seguro_completo) {
        this.seguro_completo = seguro_completo;
    }
    //aca estan los constructores que no supe usar.
    public Vehiculos(String marca, int placa, int precio, int cantidad_dias, boolean seguro_GPS, boolean seguro_completo) {
        this.marca = marca;
        this.placa = placa;
        this.precio = precio;
        this.cantidad_dias = cantidad_dias;
        this.seguro_GPS = seguro_GPS;
        this.seguro_completo = seguro_completo;
    }
    
}
